
#include "asf.h"
#include "stdio_serial.h"
#include "conf_board.h"
#include "conf_clock.h"

/** PWM frequency in Hz */
#define PWM_FREQUENCY      20000
/** Period value of PWM output waveform */
#define PERIOD_VALUE       100
/** Initial duty cycle value */
#define INIT_DUTY_VALUE    50
#define B2 (1<<3) // Mascara pro botao 2
#define B3 (1<<12) // Mascara pro botao 3

/** PWM channel instance for LEDs */
pwm_channel_t g_pwm_channel_led;

void PWM_Handler(void)
{
	static uint32_t ul_count = 0;               /* PWM counter value */
	static uint32_t ul_duty = INIT_DUTY_VALUE;  /* PWM duty cycle rate */

	  /* Configura bot�o 2 */
	if ((( PIOB->PIO_PDSR & B2 ) != B2))
	{
		ul_duty = 0;
		delay_s(1);
	}
	 /* Configura bot�o 3 */
	if ((( PIOC->PIO_PDSR & B3 ) != B3))
	{
		ul_duty = 50;
		delay_s(1);
	}
			/* Set new duty cycle */
			ul_count = 0;
			g_pwm_channel_led.channel = PIN_PWM_LED0_CHANNEL;
			pwm_channel_update_duty(PWM, &g_pwm_channel_led, ul_duty);

			g_pwm_channel_led.channel = PIN_PWM_LED1_CHANNEL;
			pwm_channel_update_duty(PWM, &g_pwm_channel_led, ul_duty);
}

int main(void)
{
	/* Initialize the SAM system */
	sysclk_init();
	board_init();

	/* Define botao 2 para controle do PWM */
	PIOC->PIO_PUER |= (1<<12);// HABILITA B2
	PIOC->PIO_ODR  |= (1<<12);// define COMO ENTRADA
	PIOC->PIO_PDSR & (1<<12); // define posi��o 12 como '1'

	PIOB->PIO_PUER |= (1<<3); // HABILITA B3
	PIOB->PIO_ODR  |= (1<<3); // define COMO ENTRADA
	PIOB->PIO_PDSR & (1<<3);  // define posi��o 12 como '1'

	
	/* Enable PWM peripheral clock */

	pmc_enable_periph_clk(ID_PWM);


	/* Disable PWM channels for LEDs */

	pwm_channel_disable(PWM, PIN_PWM_LED0_CHANNEL);
	pwm_channel_disable(PWM, PIN_PWM_LED1_CHANNEL);


	/* Set PWM clock A as PWM_FREQUENCY*PERIOD_VALUE (clock B is not used) */
	pwm_clock_t clock_setting = {
		.ul_clka = PWM_FREQUENCY * PERIOD_VALUE,
		.ul_clkb = 0,
		.ul_mck = sysclk_get_cpu_hz()
	};

	pwm_init(PWM, &clock_setting);


	/* Initialize PWM channel for LED0 */
	/* Period is left-aligned */
	g_pwm_channel_led.alignment = PWM_ALIGN_LEFT;
	/* Output waveform starts at a low level */
	g_pwm_channel_led.polarity = PWM_LOW;
	/* Use PWM clock A as source clock */
	g_pwm_channel_led.ul_prescaler = PWM_CMR_CPRE_CLKA;
	/* Period value of output waveform */
	g_pwm_channel_led.ul_period = PERIOD_VALUE;
	/* Duty cycle value of output waveform */
	g_pwm_channel_led.ul_duty = INIT_DUTY_VALUE;
	g_pwm_channel_led.channel = PIN_PWM_LED0_CHANNEL;
	pwm_channel_init(PWM, &g_pwm_channel_led);


	/* Enable channel counter event interrupt */

	pwm_channel_enable_interrupt(PWM, PIN_PWM_LED0_CHANNEL, 0);


	/* Initialize PWM channel for LED1 */
	/* Period is center-aligned */
	g_pwm_channel_led.alignment = PWM_ALIGN_CENTER;
	/* Output waveform starts at a high level */
	g_pwm_channel_led.polarity = PWM_HIGH;
	/* Use PWM clock A as source clock */
	g_pwm_channel_led.ul_prescaler = PWM_CMR_CPRE_CLKA;
	/* Period value of output waveform */
	g_pwm_channel_led.ul_period = PERIOD_VALUE;
	/* Duty cycle value of output waveform */
	g_pwm_channel_led.ul_duty = INIT_DUTY_VALUE;
	g_pwm_channel_led.channel = PIN_PWM_LED1_CHANNEL;
	pwm_channel_init(PWM, &g_pwm_channel_led);

	/* Disable channel counter event interrupt */
	pwm_channel_disable_interrupt(PWM, PIN_PWM_LED1_CHANNEL, 0);


	/* Configure interrupt and enable PWM interrupt */

	NVIC_DisableIRQ(PWM_IRQn);
	NVIC_ClearPendingIRQ(PWM_IRQn);
	NVIC_SetPriority(PWM_IRQn, 0);
	NVIC_EnableIRQ(PWM_IRQn);
	
	/* Enable PWM channels for LEDs */
	pwm_channel_enable(PWM, PIN_PWM_LED0_CHANNEL);
	pwm_channel_enable(PWM, PIN_PWM_LED1_CHANNEL);


	/* Infinite loop */
	while (1) 
	{
	}
}
